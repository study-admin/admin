<style lang="less">
    // @import "./home.less";
    @import "../../styles/common.less";
</style>
<template>
    <div class="home-main">
    12345
    </div>
</template>

<script>


export default {
    name: 'home',

    data () {
        return {

        };
    },
    computed: {
        avatorPath () {
            return localStorage.avatorImgPath;
        }
    },
    methods: {

    }
};
</script>
